
def print_triangle(n):
    if 1<= n <= 10:
        for i in range(n,0,-1):
            print("@"*i)
    else:
        pass

print_triangle(5)
print_triangle(7)
print_triangle(3)
print_triangle(12)