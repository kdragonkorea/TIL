num = int(input("숫자를 입력하시오: "))
if num > 10:
    print("OK")
