import random
grade = random.randint(1, 6)

if 1 <= grade and grade <= 3:
    print("grade",grade, "학년은 저학년 입니다.")
else :
    print("grade",grade, "학년은 고학년 입니다.")

