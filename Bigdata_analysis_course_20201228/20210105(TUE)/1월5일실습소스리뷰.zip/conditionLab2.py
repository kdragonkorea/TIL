color_name = input("영어로 색깔을 쓰시오 :")
if color_name == "red":
    print("#ff0000")
else:
    print("#000000")