# ===== stringcat  =====
price = 500
print("궁금하면 " + str(price) + "원!")

# ===== format  =====
price = 500
print("궁금하면 %d원!" % price)

# ===== format2  =====
month = 8
day = 15
anni = "광복절"
print("%d월 %d일은 %s이다." % (month, day, anni))